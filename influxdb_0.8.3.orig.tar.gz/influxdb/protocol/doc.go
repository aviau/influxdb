package protocol

// Field Names

// The order of field names in the fields array maps directly to the order of the values array.
