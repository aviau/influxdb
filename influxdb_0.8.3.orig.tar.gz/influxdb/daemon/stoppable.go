package main

type Stoppable interface {
	Stop()
}
