# Questions on Github issues

Hi, github issues are reserved for bugs and/or features
discussions. Please email your questions to the mailing list or hit us
up on the irc channel. You can find more info on the
[community page](http://influxdb.com/community/)
